plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.norwayshop.converter"
    compileSdk = 35
    defaultConfig { applicationId = "com.norwayshop.converter"; minSdk = 23; targetSdk = 28; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
}
